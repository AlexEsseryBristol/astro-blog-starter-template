// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = "Careers in Quantum";
export const SITE_DESCRIPTION = "A student-led quantum careers fair.";
